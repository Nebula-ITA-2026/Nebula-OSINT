CIAO, SIAMO IL GRUPPO ANONYMOUS ITA, VI SPIEGHIAMO ALCUNE COSE CHE DOVRESTE SAPERE RIGUARDO AL BOT

1) Il bot ha comandi legali, non illegali (OSINT, raccolta e l'analisi di informazioni pubblicamente accessibili)

2) Il bot ha bisogno dei requisiti per farlo funzionare correttamente facendo questo comando nel cmd: cd (nome dela cartella, per esempio documenti), dovrete fare poi cd NebulaOsint, poi: pip install -r requirements.txt

3) Il bot e OPEN-SOURCE, quindi non ha malware o spyware (prove nel file license)

4) Non sono responsabile dei fatti che possono accadere con questo tool (tipo dox o qualunque altra cosa) IL TOOL E OSINT.

SPERO CHE IL BOT VI PIACCIA E CIAOO